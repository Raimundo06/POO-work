# Arquivo principal
if __name__ == '__main__':
    print('Projeto Biblioteca')
