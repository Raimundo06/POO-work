# Classe Colecao
class Colecao:
    pass
