# Classe base para publicações
class Publicacao:
    pass
