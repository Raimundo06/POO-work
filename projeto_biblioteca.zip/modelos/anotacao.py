# Classe Anotacao
class Anotacao:
    pass
