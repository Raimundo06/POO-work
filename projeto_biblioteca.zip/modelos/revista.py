# Classe Revista
class Revista:
    pass
