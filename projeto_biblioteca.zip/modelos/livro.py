# Classe Livro
class Livro:
    pass
