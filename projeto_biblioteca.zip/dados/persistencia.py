# Funções de persistência
